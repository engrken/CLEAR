#!/usr/bin/env node
/* CLEAR Students selected promotion compatibility patch.  Read-only by default. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const mode = process.argv.includes('--apply') ? 'apply' : 'check';
const root = process.cwd();
const target = path.join(root, 'app', 'department', '[department]', '(protected)', 'students', 'actions.ts');
const startToken = 'export async function promoteYearLevels(';
const endToken = 'export async function saveStudent(';
const addition = "/**\n * Deprecated bulk promotion endpoint, deliberately disabled.\n * Individual student selection is mandatory to avoid accidental mass promotion.\n */\nexport async function promoteYearLevels(_department: string, _clientOrgId: string) {\n  throw new Error('Bulk year-level promotion is disabled. Select students in the roster and use Promote Selected.');\n}\n\n/**\n * Promote an explicitly selected set of students. No \"promote all\" fallback.\n * The caller's supplied organization ID is deliberately ignored.\n */\nexport async function promoteSelectedYearLevels(\n  department: string,\n  _clientOrgId: string,\n  studentInternalIds: string[],\n) {\n  const { dept, orgId, officer } = await scope(department);\n  if (!Array.isArray(studentInternalIds) || studentInternalIds.length === 0) {\n    throw new Error('Select at least one student for year-level promotion.');\n  }\n  if (studentInternalIds.length > 200) {\n    throw new Error('Promote at most 200 students in a single batch.');\n  }\n  const ids = studentInternalIds.map(str);\n  if (ids.some(id => !id || id.length > 100) || new Set(ids).size !== ids.length) {\n    throw new Error('Invalid or duplicate student selection.');\n  }\n  const advancement: Record<string, string> = {\n    '1st Year': '2nd Year',\n    '2nd Year': '3rd Year',\n    '3rd Year': '4th Year',\n    '4th Year': 'Graduated / Alumni',\n  };\n\n  const result = await prisma.$transaction(async tx => {\n    const students = await tx.student.findMany({\n      where: { organizationId: orgId, id: { in: ids } },\n      select: { id: true, studentId: true, yearLevel: true },\n    });\n    if (students.length !== ids.length) {\n      throw new Error('Selection contains a student outside this organization or a deleted record. Refresh the roster.');\n    }\n    const unsupported = students.filter(student => !advancement[student.yearLevel]);\n    if (unsupported.length > 0) {\n      throw new Error(`Cannot promote ${unsupported.length} selected student(s) with unassigned or graduated year levels. Refresh your selection.`);\n    }\n    const changes: string[] = [];\n    for (const student of students) {\n      const nextLevel = advancement[student.yearLevel];\n      const updated = await tx.student.updateMany({\n        where: { id: student.id, organizationId: orgId, yearLevel: student.yearLevel },\n        data: { yearLevel: nextLevel },\n      });\n      if (updated.count !== 1) {\n        throw new Error('A selected student year level changed during promotion. No records were promoted; refresh and retry.');\n      }\n      changes.push(`${student.studentId}: ${student.yearLevel} -> ${nextLevel}`);\n    }\n    await tx.systemLog.create({ data: {\n      organizationId: orgId,\n      user: officer,\n      action: 'PROMOTE_SELECTED_YEAR_LEVELS',\n      details: `Selected year-level promotion (${students.length}): ${changes.join('; ')}`,\n    } });\n    return students.length;\n  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable, timeout: 60000 });\n  refresh(dept);\n  return { success: true, promoted: result };\n}\n\n";
function stop(message) { console.error('ABORT:', message); process.exitCode = 1; }
if (!fs.existsSync(target)) {
  stop('Missing students/actions.ts; run from the CLEAR project root.');
} else {
  const text = fs.readFileSync(target, 'utf8');
  if (/export\s+async\s+function\s+promoteSelectedYearLevels\s*\(/.test(text)) {
    console.log('Already fixed: promoteSelectedYearLevels is exported. No changes made.');
  } else {
    const start = text.indexOf(startToken);
    const end = start < 0 ? -1 : text.indexOf(endToken, start);
    const oldBlock = start < 0 || end < 0 ? '' : text.slice(start, end);
    if (start < 0 || end < 0 || oldBlock.indexOf('PROMOTE_YEAR_LEVELS') < 0 || oldBlock.indexOf('return { success: true, promoted };') < 0) {
      stop('The existing promotion code differs from the reviewed version. Nothing was changed; merge the replacement action manually.');
    } else if (!text.includes("import { Prisma } from '@prisma/client'") || !text.includes('async function scope(') || !text.includes('function refresh(')) {
      stop('Required security imports/helpers not found. Nothing was changed.');
    } else {
      const patched = text.slice(0, start) + addition + text.slice(end);
      if (mode === 'check') {
        console.log('PASS: Old bulk-promotion block recognized; targeted safe patch is applicable.');
        console.log('No file changes. Run with --apply to install.');
      } else {
        const backups = path.join(root, '.clear-patch-backups');
        fs.mkdirSync(backups, {recursive:true});
        const date = new Date().toISOString().replace(/[:.]/g,'-');
        const backup = path.join(backups, 'students-actions-before-selected-promotion-'+date+'.ts');
        fs.copyFileSync(target, backup);
        fs.writeFileSync(target, patched, 'utf8');
        console.log('Patched:', target);
        console.log('Backup:', backup);
        console.log('Preserved all other student actions, including financial-history delete safeguards.');
      }
    }
  }
}
