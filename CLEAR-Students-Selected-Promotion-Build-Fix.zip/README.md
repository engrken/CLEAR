# CLEAR — Students Selected Promotion Build Fix

## Cause

`StudentsClient.tsx` imports `promoteSelectedYearLevels`, but the student action file restored by the recent delete-warning patch exports the earlier `promoteYearLevels` instead. This is a source mismatch, not a Turbopack cache problem or a Prisma migration problem.

## Recommended installation (targeted, safe)

1. Back up your project; extract this ZIP into your project root **without overwriting `app/`** (the complete fixed file is under `replacements/`).
2. Open CMD in your CLEAR project root.
3. Run:

```cmd
node scripts\apply-selected-promotion-build-fix.cjs --check
node scripts\apply-selected-promotion-build-fix.cjs --apply
npm run build
```

The script changes **only** the old `promoteYearLevels()` block inside `app/department/[department]/(protected)/students/actions.ts`. It preserves every other action, including the newer `deleteStudent()` result contract, and creates a backup under `.clear-patch-backups/`. It refuses to patch unfamiliar source patterns.

## Complete replacement (alternative)

The reviewed complete `actions.ts` is included under `replacements/app/department/[department]/(protected)/students/actions.ts`. Use only if your local action file corresponds to the earlier Receipt History / Student Delete Fix. Otherwise prefer the script to preserve later code changes.

Do not replace `StudentsClient.tsx`; it already calls the right selected-promotion function. The legacy bulk-promotion endpoint is disabled so that a stale caller cannot accidentally promote every eligible student.

## Security checks

- Selected IDs only; no bulk fallback.
- Tenant/role authorization through existing `scope()`.
- Reject empty, duplicate, >200 or cross-tenant selections.
- Serializable Prisma transaction with optimistic year-level condition and audit event.
- Preserve the delete restriction for students with financial history.

No database migration or Neon SQL. Run the full production build locally before deployment. This package was checked against available recent source snapshots, not your live project files.
